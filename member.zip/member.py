import json
from flask import Flask, render_template, redirect, url_for
from flask_wtf import FlaskForm
from werkzeug.utils import secure_filename
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired
from galery_form import UploadImageForm
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


class LoginForm(FlaskForm):
    id_ast = StringField('Id астронавта', validators=[DataRequired()])
    pas_ast = PasswordField('Пароль астронавта', validators=[DataRequired()])
    id_cap = StringField('Id капитана', validators=[DataRequired()])
    pas_cap = PasswordField('Пароль капитана', validators=[DataRequired()])
    submit = SubmitField('Доступ')


@app.route('/<title>')
@app.route('/index/<title>')
def index(title):
    return render_template('base.html', title=title)

@app.route('/training/<prof>')
def training(prof):
    return render_template('training.html', prof=prof)

@app.route('/list_prof/<list>')
def list_prof(list):
    return render_template('list_prof.html', list=list)

@app.route('/answer')
@app.route('/auto_answer')
def auto_ans():
    d = {
        'Фамилия:': 'Watny',
        'Имя:': 'Mark',
        'Образование:': 'выше среднего',
        'Профессия:': 'штурман марсохода',
        'Пол:': 'male',
        'Мотивация:': 'Всегда мечтал застрять на Марсе!',
        'Готовы остаться на Марсе?': 'True'
    }
    return render_template('auto_answer.html', title='Анкета', data=d)

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        return 'Форма отправлена'
    return render_template('login.html', title='Аварийный доступ', form=form)

@app.route('/distribution')
def distribution():
    list_ast = ['Ридли Скотт', 'Энди Уир', 'Марк Уотни', 'Венката Капур', 'Тедди Сандерс', 'Шон Бин']
    return render_template('distribution.html', lst=list_ast)

@app.route('/table/<s>/<age>')
def table(s, age):
    return render_template('table.html', s=s, age=int(age))


@app.route('/galery', methods=['GET', 'POST'])
def galery():
    form = UploadImageForm()
    path = os.path.join(app.static_folder, 'img1')
    images = []
    for i in os.listdir(path):
        images.append(i)
    if form.validate_on_submit():
        file = form.image.data
        filename = secure_filename(file.filename)
        file.save(os.path.join(path, filename))
        return redirect(url_for('galery'))
    return render_template('galery.html', form=form, images=images)

@app.route('/member')
def member():
    with open("templates/member.json", "rt", encoding="utf8") as f:
        members = json.loads(f.read())
    return render_template('members.html', members=members)

if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')