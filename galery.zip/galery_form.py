from flask_wtf import FlaskForm
from wtforms import FileField, SubmitField
from wtforms.validators import DataRequired
from werkzeug.utils import secure_filename

class UploadImageForm(FlaskForm):
    image = FileField('Выберите изображение', validators=[DataRequired()])
    submit = SubmitField('Загрузить')